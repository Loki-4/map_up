# Question 9: Distance Matrix Calculation
import pandas as pd

def calculate_distance_matrix(file_path):
  
    df = pd.read_csv(file_path)
    
 
    distance_matrix = pd.pivot_table(df, values='distance', index='id_start', columns='id_end', fill_value=0)
    

    for row in distance_matrix.index:
        for col in distance_matrix.columns:
            if distance_matrix.at[row, col] == 0 and distance_matrix.at[col, row] > 0:
                distance_matrix.at[row, col] = distance_matrix.at[col, row]
    

    for id in distance_matrix.index:
        distance_matrix.at[id, id] = 0
    
    return distance_matrix




# Question 10: Unroll Distance Matrix
def unroll_distance_matrix(distance_matrix):
    # Create an unrolled DataFrame
    unrolled_df = distance_matrix.stack().reset_index()
    unrolled_df.columns = ['id_start', 'id_end', 'distance']
    
    # Filter out same id_start and id_end
    unrolled_df = unrolled_df[unrolled_df['id_start'] != unrolled_df['id_end']]
    
    return unrolled_df





# Question 11: Finding IDs within Percentage Threshold
def find_ids_within_ten_percentage_threshold(unrolled_df, reference_id):
    # Calculate average distance for the reference id
    avg_distance = unrolled_df[unrolled_df['id_start'] == reference_id]['distance'].mean()
    
    # Define the percentage range
    lower_bound = avg_distance * 0.9
    upper_bound = avg_distance * 1.1
    
    # Find IDs within the specified threshold
    result_ids = unrolled_df[(unrolled_df['id_start'] != reference_id) & 
                              (unrolled_df['distance'] >= lower_bound) & 
                              (unrolled_df['distance'] <= upper_bound)]
    
    return result_ids['id_start'].unique().tolist()



# Question 12: Calculate Toll Rate

def calculate_toll_rate(unrolled_df):
    toll_rate_df = unrolled_df.copy()
    
    # Define toll rate coefficients
    rate_coefficients = {
        'moto': 0.8,
        'car': 1.2,
        'rv': 1.5,
        'bus': 2.2,
        'truck': 3.6
    }
    
    # Calculate toll rates
    for vehicle_type, coefficient in rate_coefficients.items():
        toll_rate_df[vehicle_type] = toll_rate_df['distance'] * coefficient
    
    return toll_rate_df



# Question 13: Calculate Time-Based Toll Rates

from datetime import time, timedelta

def calculate_time_based_toll_rates(toll_rate_df):
    # Prepare a DataFrame to store time intervals
    time_based_df = pd.DataFrame(columns=toll_rate_df.columns.tolist() + 
                                  ['start_day', 'start_time', 'end_day', 'end_time'])
    
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    
    # Iterate through all unique id_start and id_end pairs
    for _, row in toll_rate_df.iterrows():
        for day in days:
            for start_hour in range(24):
                for end_hour in range(start_hour + 1, 25):  # Ensure end_hour > start_hour
                    start_time = time(start_hour, 0)
                    end_time = time(end_hour % 24, 0)
                    
                    if day in days[:5]:  # Weekdays
                        if start_hour < 10:  # Discount for 00:00 to 10:00
                            factor = 0.8
                        elif start_hour < 18:  # Discount for 10:00 to 18:00
                            factor = 1.2
                        else:  # Discount for 18:00 to 23:59
                            factor = 0.8
                    else:  # Weekends
                        factor = 0.7
                    
                    # Create a new row for the DataFrame
                    new_row = row.to_dict()
                    new_row['start_day'] = day
                    new_row['start_time'] = start_time
                    new_row['end_day'] = day
                    new_row['end_time'] = end_time
                    
                    # Apply the factor to each vehicle type
                    for vehicle in ['moto', 'car', 'rv', 'bus', 'truck']:
                        new_row[vehicle] *= factor
                    
                    # Append the new row to the DataFrame
                    time_based_df = time_based_df.append(new_row, ignore_index=True)
    
    return time_based_df

